# Python script to load CSV data into MySQL
